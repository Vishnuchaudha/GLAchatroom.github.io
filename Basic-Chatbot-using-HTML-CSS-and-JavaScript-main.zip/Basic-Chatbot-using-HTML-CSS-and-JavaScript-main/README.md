# My_Chatbot

## Preview

![chatbot-2](https://github.com/hegdepavankumar/Basic-Chatbot-using-HTML-CSS-and-JavaScript/assets/85627085/54b7bff0-cd2a-43b6-b29f-2303874d1474)
